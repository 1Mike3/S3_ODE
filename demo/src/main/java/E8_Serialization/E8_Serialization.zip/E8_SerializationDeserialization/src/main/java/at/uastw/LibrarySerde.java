package at.uastw;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;


import java.io.File;

public class LibrarySerde implements Serde {

    // TODO: implementieren Sie beide Methoden mithilfe von Jackson
    @Override
    public String serializeLibrary(Library library) {
        //throw new UnsupportedOperationException("Not implemented yet");

        ObjectMapper mapper = new ObjectMapper();

        try {
            String json = mapper.writeValueAsString(library);

            // some extra Print stuff to look at the output
            mapper.writeValue(new File("library.json"), library);
            System.out.println(json);

            return json;
        } catch (Exception e) {
        System.out.println("This not good: " + e);
            return null;
        }

    }

    @Override
    public Library deserializeLibrary(String libraryJson)  {
        //throw new UnsupportedOperationException("Not implemented yet");
        ObjectMapper mapper = new ObjectMapper();

        try{
            Library library = mapper.readValue(libraryJson, Library.class);
            return library;
        } catch (Exception e) {
            System.out.println("This not good: " + e);
            return null;
        }

    }
}